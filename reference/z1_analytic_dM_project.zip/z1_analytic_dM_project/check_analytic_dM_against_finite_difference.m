clear;
clc;

%% Check analytic dM against finite difference of analytic M
% This checks only dM, independent of generated symbolic files.

p = z1_parameters_analytic();
q = [0.20; 0.25; -0.25; 0.15; 0.10; 0.04];

[M, dM] = z1_mass_and_dM_analytic(q, p);

eps_list = [1e-3 1e-4 1e-5 1e-6 1e-7];

fprintf('\nCheck analytic dM against finite difference of M(q)\n');
fprintf('--------------------------------------------------\n');
fprintf('%12s | %12s %12s %12s\n', 'eps', 'max_abs', 'fro_total', 'best_k');
fprintf('%s\n', repmat('-', 1, 58));

for eps_fd = eps_list
    max_err = 0;
    fro_total = 0;
    best_k = 0;

    for k = 1:6
        e = zeros(6,1);
        e(k) = eps_fd;

        M_plus = z1_mass_and_dM_analytic(q + e, p);
        M_minus = z1_mass_and_dM_analytic(q - e, p);
        dM_fd = (M_plus - M_minus) / (2*eps_fd);

        err = norm(dM(:,:,k) - dM_fd, 'fro');
        fro_total = fro_total + err;
        if err > max_err
            max_err = err;
            best_k = k;
        end
    end

    fprintf('%12.1e | %12.4e %12.4e %12d\n', eps_fd, max_err, fro_total, best_k);
end
