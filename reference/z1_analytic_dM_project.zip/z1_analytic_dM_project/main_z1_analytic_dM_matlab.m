
% main_z1_analytic_dM_matlab.m
% Unitree Z1-style dynamics demo using analytic dM/dq from the Lie-bracket formula.
%
% No symbolic math.
% No finite difference for dM during simulation.
%
% This script calculates:
%   M(q)
%   dM/dq analytically using dJ/dq = A_lk * lie_bracket(A_kj * xi_j, xi_k)
%   C(q,dq) from dM/dq
%   N(q) from COM Jacobians
%   qdd = M \ (tau - C*dq - N - B*dq)
%
% To run:
%   Open this file in MATLAB and press Run,
%   or type: main_z1_analytic_dM_matlab
%
% The first section below has the only user settings you usually edit.

clear;
clc;
close all;

%% User settings
do_check = true;       % compare analytic dM against finite-difference dM at one point
do_simulate = true;    % run torque-to-q simulation
make_plots = true;     % show q, dq, tau plots

dt = 0.01;             % fixed simulation step [s]
t_end = 3.0;           % simulation duration [s]
csv_path = 'z1_matlab_sim_log.csv';

%% Run check and simulation
if do_check
    check_against_finite_difference();
end

if do_simulate
    log = simulate_z1(t_end, dt, csv_path);

    % Print max torque like the Python check
    fprintf('\nMax absolute torque from simulation log:\n');
    for j = 1:6
        [max_abs_tau, idx] = max(abs(log.tau(:,j)));
        fprintf('tau%d max abs = %.12g, value = %.12g, time = %.4f\n', ...
            j, max_abs_tau, log.tau(idx,j), log.t(idx));
    end

    if make_plots
        plot_logs(log);
    end
end

%% ========================= Local functions =========================

function S = skew3(a)
    a = a(:);
    S = [0, -a(3), a(2); ...
         a(3), 0, -a(1); ...
        -a(2), a(1), 0];
end

function I = inertia_from_urdf(ixx, ixy, ixz, iyy, iyz, izz)
    I = [ixx, ixy, ixz; ...
         ixy, iyy, iyz; ...
         ixz, iyz, izz];
end

function I_shifted = parallel_axis_theorem(I_body, m_body, displacement)
    d = displacement(:);
    I_shifted = I_body + m_body * ((d.'*d) * eye(3) - d*d.');
end

function g = make_g(R, p)
    g = eye(4);
    g(1:3,1:3) = R;
    g(1:3,4) = p(:);
end

function Ad = adjoint(g)
    % Adjoint for twist convention xi = [v; w].
    R = g(1:3,1:3);
    p = g(1:3,4);
    Ad = zeros(6,6);
    Ad(1:3,1:3) = R;
    Ad(1:3,4:6) = skew3(p) * R;
    Ad(4:6,4:6) = R;
end

function Adi = adjoint_inverse(g)
    % Inverse adjoint for twist convention xi = [v; w].
    R = g(1:3,1:3);
    p = g(1:3,4);
    Adi = zeros(6,6);
    Adi(1:3,1:3) = R.';
    Adi(1:3,4:6) = -R.' * skew3(p);
    Adi(4:6,4:6) = R.';
end

function R = rodrigues(w, theta)
    w = w(:);
    W = skew3(w);
    I3 = eye(3);
    nw = norm(w);

    if abs(nw - 1.0) < 1e-12
        R = I3 + W*sin(theta) + W*W*(1 - cos(theta));
    else
        R = I3 + (W/nw)*sin(nw*theta) + (W*W/(nw*nw))*(1 - cos(nw*theta));
    end
end

function g = twist_exp(w, v, theta)
    % Homogeneous transform e^[xi_hat theta], xi=[v;w].
    w = w(:);
    v = v(:);
    R = rodrigues(w, theta);
    p = (eye(3) - R) * (skew3(w) * v) + w * (w.' * v) * theta;
    g = make_g(R, p);
end

function out = lie_bracket_vw(xi1, xi2)
    % Lie bracket for twists with convention xi = [v; w].
    xi1 = xi1(:);
    xi2 = xi2(:);
    v1 = xi1(1:3);
    w1 = xi1(4:6);
    v2 = xi2(1:3);
    w2 = xi2(4:6);

    v_bracket = cross(w1, v2) + cross(v1, w2);
    w_bracket = cross(w1, w2);
    out = [v_bracket; w_bracket];
end

function p = z1_parameters()
    p.g_const = 9.80665;

    p.m_vec = [0.67332551; ...
               1.19132258; ...
               0.83940874; ...
               0.56404563; ...
               0.38938492; ...
               0.0];

    I1 = inertia_from_urdf(0.00128328, -6e-08,  -4e-07, 0.00071931,  5e-07, 0.00083936);
    I2 = inertia_from_urdf(0.00102138,  0.00062358, 5.13e-06, 0.02429457, -2.1e-06, 0.02466114);
    I3 = inertia_from_urdf(0.00108061, -8.669e-05, -0.00208102, 0.00954238, -1.332e-05, 0.00886621);
    I4 = inertia_from_urdf(0.00031576,  8.13e-05,  4.091e-05, 0.00092996, -5.96e-06, 0.00097912);
    I5 = inertia_from_urdf(0.00017605,  4e-07,    5.689e-05, 0.00055896, -1.3e-07, 0.00053860);

    % Combine link06 + gripper parts into one effective link 6.
    m_link06 = 0.28875807;
    c_link06 = [0.0241569; -0.00017355; -0.00143876];
    I_link06 = inertia_from_urdf(0.00018328, 1.22e-06, 5.4e-07, 0.0001475, 8e-08, 0.0001468);

    m_gripper_stator = 0.52603655;
    c_gripper_stator = [0.04764427; -0.00035819; -0.00249162];
    I_gripper_stator = inertia_from_urdf(0.00038683, -0.00000359, 0.00007662, 0.00068614, 0.00000209, 0.00066293);

    m_gripper_mover = 0.27621302;
    c_gripper_mover = [0.01320633; 0.00476708; 0.00380534];
    I_gripper_mover = inertia_from_urdf(0.00017716, 0.00001683, -0.00001786, 0.00026787, 0.00000262, 0.00035728);

    gripper_joint_origin = [0.051; 0.0; 0.0];

    m_total = m_link06 + m_gripper_stator + m_gripper_mover;
    c_gripper_stator_in_link06 = gripper_joint_origin + c_gripper_stator;
    c_gripper_mover_in_link06 = gripper_joint_origin + c_gripper_mover;

    c_combined = (m_link06*c_link06 + ...
                  m_gripper_stator*c_gripper_stator_in_link06 + ...
                  m_gripper_mover*c_gripper_mover_in_link06) / m_total;

    I_link06_at_combined = parallel_axis_theorem(I_link06, m_link06, c_link06 - c_combined);
    I_gripper_stator_at_combined = parallel_axis_theorem(I_gripper_stator, m_gripper_stator, c_gripper_stator_in_link06 - c_combined);
    I_gripper_mover_at_combined = parallel_axis_theorem(I_gripper_mover, m_gripper_mover, c_gripper_mover_in_link06 - c_combined);
    I6 = I_link06_at_combined + I_gripper_stator_at_combined + I_gripper_mover_at_combined;

    p.m_vec(6) = m_total;
    p.I = {I1, I2, I3, I4, I5, I6};

    % Joint axes at home. Each column is one joint axis w_i.
    p.w = [0.0, 0.0, 0.0, 0.0, 0.0, 1.0; ...
           0.0, 1.0, 1.0, 1.0, 0.0, 0.0; ...
           1.0, 0.0, 0.0, 0.0, 1.0, 0.0];

    % Points on joint axes at home. Each column is q_i.
    p.q_axis = [0.0,     0.0,   -0.35,  -0.132, -0.062, -0.0128; ...
                0.0,     0.0,    0.0,    0.0,    0.0,    0.0; ...
                0.0585,  0.1035, 0.1035, 0.1605, 0.1605, 0.1605];

    % COM offsets relative to joint/home frame points. Each column is c_i.
    p.c = [ 2.47e-06,   -0.11012601,  0.10609208,  0.04366681, 0.03121533, c_combined(1); ...
           -0.00025198,  0.00240029, -0.00541815,  0.00364738, 0.0,        c_combined(2); ...
            0.02317169,  0.00158266,  0.03476383, -0.00170192, 0.00646316, c_combined(3)];

    p.gsl0 = cell(1,6);
    for i = 1:6
        p.gsl0{i} = make_g(eye(3), p.q_axis(:,i) + p.c(:,i));
    end
end

function [xi, w_list, v_list] = z1_twists(p)
    w_list = p.w;
    v_list = zeros(3,6);
    xi = zeros(6,6);
    for i = 1:6
        w = w_list(:,i);
        q0 = p.q_axis(:,i);
        v = -cross(w, q0);
        v_list(:,i) = v;
        xi(:,i) = [v; w];
    end
end

function [A, Gp, xi] = compute_A_and_Gp(q, p)
    q = q(:);
    [xi, w_list, v_list] = z1_twists(p);

    E = cell(1,6);
    for i = 1:6
        E{i} = twist_exp(w_list(:,i), v_list(:,i), q(i));
    end

    % A(:,:,l,j) = A_lj. It transforms joint j twist into link l frame.
    A = zeros(6,6,6,6);
    for l = 1:6
        for j = 1:6
            if l < j
                A(:,:,l,j) = zeros(6,6);
            elseif l == j
                A(:,:,l,j) = eye(6);
            else
                g = eye(4);
                for r = (j+1):l
                    g = g * E{r};
                end
                A(:,:,l,j) = adjoint_inverse(g);
            end
        end
    end

    % Transformed spatial inertia for each link, in the home/base convention.
    Gp = zeros(6,6,6);
    for l = 1:6
        G = zeros(6,6);
        G(1:3,1:3) = p.m_vec(l) * eye(3);
        G(4:6,4:6) = p.I{l};
        A0 = adjoint_inverse(p.gsl0{l});
        Gp(:,:,l) = A0.' * G * A0;
    end
end

function dJ = dJ_column_analytic(l, j, k, A, xi)
    % d/dq_k of J_lj = A_lj xi_j.
    % This is the book formula:
    %   dJ_lj/dq_k = A_lk * [A_kj*xi_j, xi_k]
    if ~(l >= k && k >= j)
        dJ = zeros(6,1);
        return;
    end

    A_lk = A(:,:,l,k);
    A_kj_xi_j = A(:,:,k,j) * xi(:,j);
    xi_k = xi(:,k);
    dJ = A_lk * lie_bracket_vw(A_kj_xi_j, xi_k);
end

function [M, dM] = mass_and_dM_analytic(q, p)
    [A, Gp, xi] = compute_A_and_Gp(q, p);

    % J(:,l,j) = A_lj * xi_j
    J = zeros(6,6,6);
    for l = 1:6
        for j = 1:l
            J(:,l,j) = A(:,:,l,j) * xi(:,j);
        end
    end

    % GJ(:,l,j) = Gp_l * J_lj
    GJ = zeros(6,6,6);
    for l = 1:6
        for j = 1:6
            GJ(:,l,j) = Gp(:,:,l) * J(:,l,j);
        end
    end

    % Mass matrix M(i,j) = sum_l J_li' * Gp_l * J_lj
    M = zeros(6,6);
    for i = 1:6
        for j = 1:6
            val = 0.0;
            for l = max(i,j):6
                val = val + J(:,l,i).' * GJ(:,l,j);
            end
            M(i,j) = val;
        end
    end
    M = 0.5 * (M + M.');

    % dJ(:,l,j,k) = d/dq_k of J_lj
    dJ = zeros(6,6,6,6);
    for l = 1:6
        for j = 1:l
            for k = j:l
                dJ(:,l,j,k) = dJ_column_analytic(l, j, k, A, xi);
            end
        end
    end

    % GdJ(:,l,j,k) = Gp_l * dJ_lj_dqk
    GdJ = zeros(6,6,6,6);
    for l = 1:6
        for j = 1:6
            for k = 1:6
                GdJ(:,l,j,k) = Gp(:,:,l) * dJ(:,l,j,k);
            end
        end
    end

    % dM(i,j,k) = dM_ij / dq_k
    dM = zeros(6,6,6);
    for k = 1:6
        for i = 1:6
            for j = 1:6
                val = 0.0;
                for l = max(i,j):6
                    val = val + dJ(:,l,i,k).' * GJ(:,l,j) + J(:,l,i).' * GdJ(:,l,j,k);
                end
                dM(i,j,k) = val;
            end
        end
    end
end

function M = mass_matrix_analytic(q, p)
    [A, Gp, xi] = compute_A_and_Gp(q, p);
    J = zeros(6,6,6);
    for l = 1:6
        for j = 1:l
            J(:,l,j) = A(:,:,l,j) * xi(:,j);
        end
    end

    M = zeros(6,6);
    for i = 1:6
        for j = 1:6
            val = 0.0;
            for l = max(i,j):6
                val = val + J(:,l,i).' * Gp(:,:,l) * J(:,l,j);
            end
            M(i,j) = val;
        end
    end
    M = 0.5 * (M + M.');
end

function C = coriolis_from_dM(dM, dq)
    dq = dq(:);
    C = zeros(6,6);
    for i = 1:6
        for j = 1:6
            val = 0.0;
            for k = 1:6
                val = val + 0.5 * (dM(i,j,k) + dM(i,k,j) - dM(k,j,i)) * dq(k);
            end
            C(i,j) = val;
        end
    end
end

function N = gravity_vector_analytic(q, p)
    q = q(:);
    [xi, w_list, v_list] = z1_twists(p);

    E = cell(1,6);
    for i = 1:6
        E{i} = twist_exp(w_list(:,i), v_list(:,i), q(i));
    end

    % COM positions in space/base frame
    p_com = zeros(3,6);
    for l = 1:6
        g = eye(4);
        for r = 1:l
            g = g * E{r};
        end
        g_com = g * p.gsl0{l};
        p_com(:,l) = g_com(1:3,4);
    end

    % Space Jacobian columns for each joint
    J_space = zeros(6,6);
    T_prev = eye(4);
    for j = 1:6
        J_space(:,j) = adjoint(T_prev) * xi(:,j);
        T_prev = T_prev * E{j};
    end

    N = zeros(6,1);
    for j = 1:6
        vj = J_space(1:3,j);
        wj = J_space(4:6,j);
        for l = j:6
            dp = vj + cross(wj, p_com(:,l));
            N(j) = N(j) + p.m_vec(l) * p.g_const * dp(3);
        end
    end
end

function [M, C, N, dM] = dynamics_analytic(q, dq, p)
    [M, dM] = mass_and_dM_analytic(q, p);
    C = coriolis_from_dM(dM, dq);
    N = gravity_vector_analytic(q, p);
end

function [qd, dqd, ddqd] = desired_trajectory(t)
    q_target = [0.20; 0.25; -0.25; 0.15; 0.10; 0.10];
    t0 = 0.2;
    T = 1.3;
    s = (t - t0) / T;

    if s <= 0.0
        b = 0.0;
        bd = 0.0;
        bdd = 0.0;
    elseif s >= 1.0
        b = 1.0;
        bd = 0.0;
        bdd = 0.0;
    else
        b = 10*s^3 - 15*s^4 + 6*s^5;
        bd = (30*s^2 - 60*s^3 + 30*s^4) / T;
        bdd = (60*s - 180*s^2 + 120*s^3) / (T*T);
    end

    qd = q_target * b;
    dqd = q_target * bd;
    ddqd = q_target * bdd;
end

function log = simulate_z1(t_end, dt, csv_path)
    p = z1_parameters();
    damping = diag([0.02, 0.02, 0.02, 0.01, 0.01, 0.005]);

    steps = round(t_end / dt);
    q = zeros(6,1);
    dq = zeros(6,1);

    t_log = zeros(steps+1,1);
    q_log = zeros(steps+1,6);
    dq_log = zeros(steps+1,6);
    tau_log = zeros(steps+1,6);

    q_log(1,:) = q.';
    dq_log(1,:) = dq.';

    Kp = diag([80, 80, 70, 55, 35, 25]);
    Kd = diag([16, 16, 14, 11, 7, 5]);

    tic;
    for kstep = 1:steps
        t = (kstep - 1) * dt;

        % Calculate dynamics once per controller step.
        [M, C, N, ~] = dynamics_analytic(q, dq, p);
        [qd, dqd, ddqd] = desired_trajectory(t);

        tau = M * (ddqd + Kd*(dqd - dq) + Kp*(qd - q)) + C*dq + N;
        qdd = M \ (tau - C*dq - N - damping*dq);

        % Semi-implicit Euler update.
        dq = dq + qdd * dt;
        q = q + dq * dt;

        t_log(kstep+1) = t + dt;
        q_log(kstep+1,:) = q.';
        dq_log(kstep+1,:) = dq.';
        tau_log(kstep+1,:) = tau.';
    end
    elapsed = toc;

    log.t = t_log;
    log.q = q_log;
    log.dq = dq_log;
    log.tau = tau_log;

    % Write CSV
    names = [{'t'}, arrayfun(@(i)sprintf('q%d',i), 1:6, 'UniformOutput', false), ...
                  arrayfun(@(i)sprintf('dq%d',i), 1:6, 'UniformOutput', false), ...
                  arrayfun(@(i)sprintf('tau%d',i), 1:6, 'UniformOutput', false)];
    T = array2table([t_log, q_log, dq_log, tau_log], 'VariableNames', names);
    writetable(T, csv_path);

    fprintf('\nSimulation finished: %d steps in %.2f s\n', steps, elapsed);
    fprintf('CSV log written: %s\n', csv_path);
end

function dM_fd = finite_difference_dM(q, p, eps_fd)
    q = q(:);
    dM_fd = zeros(6,6,6);
    for k = 1:6
        e = zeros(6,1);
        e(k) = eps_fd;
        Mp = mass_matrix_analytic(q + e, p);
        Mm = mass_matrix_analytic(q - e, p);
        dM_fd(:,:,k) = (Mp - Mm) / (2 * eps_fd);
    end
end

function check_against_finite_difference()
    p = z1_parameters();
    q = [0.20; 0.25; -0.25; 0.15; 0.10; 0.10];
    dq = [0.50; -0.30; 0.20; -0.10; 0.40; -0.20];

    [M, dM] = mass_and_dM_analytic(q, p);
    C = coriolis_from_dM(dM, dq);
    N = gravity_vector_analytic(q, p);

    dM_fd = finite_difference_dM(q, p, 1e-6);
    C_fd = coriolis_from_dM(dM_fd, dq);

    fprintf('Check analytic dM against finite-difference dM at one point\n');
    fprintf('q  = [%g %g %g %g %g %g]\n', q);
    fprintf('dq = [%g %g %g %g %g %g]\n', dq);
    fprintf('M condition number = %.12g\n', cond(M));
    fprintf('max abs dM error = %.12g\n', max(abs(dM(:) - dM_fd(:))));
    fprintf('fro dM error     = %.12g\n', norm(dM(:) - dM_fd(:)));
    fprintf('C*dq analytic    = [%s]\n', sprintf(' %.8g', (C*dq).'));
    fprintf('C*dq finite diff = [%s]\n', sprintf(' %.8g', (C_fd*dq).'));
    fprintf('C*dq error norm  = %.12g\n', norm(C*dq - C_fd*dq));
    fprintf('N(q)             = [%s]\n', sprintf(' %.8g', N.'));
end

function plot_logs(log)
    figure;
    plot(log.t, log.q, 'LineWidth', 1.2);
    grid on;
    xlabel('Time [s]');
    ylabel('q [rad]');
    title('Z1 MATLAB analytic dM: joint position');
    legend('q1','q2','q3','q4','q5','q6', 'Location', 'best');

    figure;
    plot(log.t, log.dq, 'LineWidth', 1.2);
    grid on;
    xlabel('Time [s]');
    ylabel('dq [rad/s]');
    title('Z1 MATLAB analytic dM: joint velocity');
    legend('dq1','dq2','dq3','dq4','dq5','dq6', 'Location', 'best');

    figure;
    plot(log.t, log.tau, 'LineWidth', 1.2);
    grid on;
    xlabel('Time [s]');
    ylabel('tau [N m]');
    title('Z1 MATLAB analytic dM: commanded torque');
    legend('tau1','tau2','tau3','tau4','tau5','tau6', 'Location', 'best');
end
