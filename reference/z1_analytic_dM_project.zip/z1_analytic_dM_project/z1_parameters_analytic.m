function p = z1_parameters_analytic()
%Z1_PARAMETERS_ANALYTIC Unitree Z1 parameters.
% Values are translated from the user's Z1 parameter file.

p = struct();

p.g_const = 9.80665;

p.m_vec = [ ...
    0.67332551; ...
    1.19132258; ...
    0.83940874; ...
    0.56404563; ...
    0.38938492; ...
    0.0];

p.I1 = inertia_from_urdf(0.00128328, -6e-08,  -4e-07, 0.00071931,  5e-07, 0.00083936);
p.I2 = inertia_from_urdf(0.00102138,  0.00062358, 5.13e-06, 0.02429457, -2.1e-06, 0.02466114);
p.I3 = inertia_from_urdf(0.00108061, -8.669e-05, -0.00208102, 0.00954238, -1.332e-05, 0.00886621);
p.I4 = inertia_from_urdf(0.00031576,  8.13e-05,  4.091e-05, 0.00092996, -5.96e-06, 0.00097912);
p.I5 = inertia_from_urdf(0.00017605,  4e-07,    5.689e-05, 0.00055896, -1.3e-07, 0.00053860);

m_link06 = 0.28875807;
c_link06 = [0.0241569; -0.00017355; -0.00143876];
I_link06 = inertia_from_urdf(0.00018328, 1.22e-06, 5.4e-07, 0.0001475, 8e-08, 0.0001468);

m_gripper_stator = 0.52603655;
c_gripper_stator = [0.04764427; -0.00035819; -0.00249162];
I_gripper_stator = inertia_from_urdf(0.00038683, -0.00000359, 0.00007662, 0.00068614, 0.00000209, 0.00066293);

m_gripper_mover = 0.27621302;
c_gripper_mover = [0.01320633; 0.00476708; 0.00380534];
I_gripper_mover = inertia_from_urdf(0.00017716, 0.00001683, -0.00001786, 0.00026787, 0.00000262, 0.00035728);

gripper_joint_origin = [0.051; 0.0; 0.0];

m_total = m_link06 + m_gripper_stator + m_gripper_mover;
c_gripper_stator_in_link06 = gripper_joint_origin + c_gripper_stator;
c_gripper_mover_in_link06 = gripper_joint_origin + c_gripper_mover;

c_combined = (m_link06 * c_link06 + ...
              m_gripper_stator * c_gripper_stator_in_link06 + ...
              m_gripper_mover * c_gripper_mover_in_link06) / m_total;

d_link06 = c_link06 - c_combined;
d_gripper_stator = c_gripper_stator_in_link06 - c_combined;
d_gripper_mover = c_gripper_mover_in_link06 - c_combined;

I_link06_at_combined = parallel_axis_theorem(I_link06, m_link06, d_link06);
I_gripper_stator_at_combined = parallel_axis_theorem(I_gripper_stator, m_gripper_stator, d_gripper_stator);
I_gripper_mover_at_combined = parallel_axis_theorem(I_gripper_mover, m_gripper_mover, d_gripper_mover);

I_combined = I_link06_at_combined + I_gripper_stator_at_combined + I_gripper_mover_at_combined;

p.I6 = I_combined;
p.m_vec(6) = m_total;

p.w1 = [0.0; 0.0; 1.0];
p.w2 = [0.0; 1.0; 0.0];
p.w3 = [0.0; 1.0; 0.0];
p.w4 = [0.0; 1.0; 0.0];
p.w5 = [0.0; 0.0; 1.0];
p.w6 = [1.0; 0.0; 0.0];

p.q1 = [0.0;     0.0; 0.0585];
p.q2 = [0.0;     0.0; 0.1035];
p.q3 = [-0.35;   0.0; 0.1035];
p.q4 = [-0.132;  0.0; 0.1605];
p.q5 = [-0.062;  0.0; 0.1605];
p.q6 = [-0.0128; 0.0; 0.1605];

p.c1 = [ 2.47e-06;   -0.00025198;  0.02317169];
p.c2 = [-0.11012601;  0.00240029;  0.00158266];
p.c3 = [ 0.10609208; -0.00541815;  0.03476383];
p.c4 = [ 0.04366681;  0.00364738; -0.00170192];
p.c5 = [ 0.03121533;  0.0;         0.00646316];
p.c6 = c_combined;

p.gsl0_1 = make_g(eye(3), p.q1 + p.c1);
p.gsl0_2 = make_g(eye(3), p.q2 + p.c2);
p.gsl0_3 = make_g(eye(3), p.q3 + p.c3);
p.gsl0_4 = make_g(eye(3), p.q4 + p.c4);
p.gsl0_5 = make_g(eye(3), p.q5 + p.c5);
p.gsl0_6 = make_g(eye(3), p.q6 + p.c6);
end
