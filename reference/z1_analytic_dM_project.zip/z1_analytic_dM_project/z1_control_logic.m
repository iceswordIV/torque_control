function tau_cmd = z1_control_logic(t, q, dq, ctrl, p)
%Z1_CONTROL_LOGIC PD plus optional gravity compensation.

[q_des, dq_des, ddq_des] = z1_desired_trajectory(t, ctrl.q_goal, ctrl.t0, ctrl.Tmove);

Kp = diag(ctrl.Kp(:));
Kd = diag(ctrl.Kd(:));

e = q_des - q;
de = dq_des - dq;

% This controller is intentionally simple.
% It does not need C. It optionally adds gravity compensation.
tau_cmd = Kp*e + Kd*de + ddq_des*0;

if isfield(ctrl, 'use_gravity_compensation') && ctrl.use_gravity_compensation
    N = z1_gravity_vector_analytic(q, p);
    tau_cmd = tau_cmd + N;
end
end
