clear;
clc;

%% Compare analytic dM backend against generated symbolic backend
% This script is optional. The simulation does not need M_func/C_func/N_func.
% The generated files are used here only as a reference.

if exist('reference_generated', 'dir')
    addpath('reference_generated');
end

if exist('M_func.m', 'file') ~= 2 || exist('C_func.m', 'file') ~= 2 || exist('N_func.m', 'file') ~= 2
    error('M_func.m, C_func.m, N_func.m not found. Put them in this folder or reference_generated/.');
end

p = z1_parameters_analytic();

q = [0.20; 0.25; -0.25; 0.15; 0.10; 0.04];
dq = [0.50; -0.30; 0.20; -0.10; 0.40; -0.20];
tau = [0.1; 3.0; -7.8; -2.6; 0.02; 0.01];

[M_a, C_a, N_a, dM_a] = z1_dynamics_analytic(q, dq, p);

M_ref = M_func(q);
C_ref = C_func(q, dq);
N_ref = N_func(q);

Cdq_a = C_a * dq;
Cdq_ref = C_ref * dq;

ddq_a = M_a \ (tau - Cdq_a - N_a);
ddq_ref = M_ref \ (tau - Cdq_ref - N_ref);

fprintf('\nAnalytic dM backend compared with generated symbolic backend\n');
fprintf('--------------------------------------------------------\n');
fprintf('M abs error       = %.6e\n', norm(M_a - M_ref, 'fro'));
fprintf('M rel error       = %.6e\n', norm(M_a - M_ref, 'fro') / max(1, norm(M_ref, 'fro')));
fprintf('N abs error       = %.6e\n', norm(N_a - N_ref));
fprintf('N rel error       = %.6e\n', norm(N_a - N_ref) / max(1, norm(N_ref)));
fprintf('C*dq abs error    = %.6e\n', norm(Cdq_a - Cdq_ref));
fprintf('C*dq rel error    = %.6e\n', norm(Cdq_a - Cdq_ref) / max(1, norm(Cdq_ref)));
fprintf('ddq abs error     = %.6e\n', norm(ddq_a - ddq_ref));
fprintf('ddq rel error     = %.6e\n', norm(ddq_a - ddq_ref) / max(1, norm(ddq_ref)));

fprintf('\nq =\n'); disp(q.');
fprintf('dq =\n'); disp(dq.');

fprintf('N analytic =\n'); disp(N_a.');
fprintf('N reference =\n'); disp(N_ref.');
fprintf('C*dq analytic =\n'); disp(Cdq_a.');
fprintf('C*dq reference =\n'); disp(Cdq_ref.');

% A useful property: dM_k should be approximately symmetric in i,j because M is symmetric.
sym_err = zeros(6,1);
for k = 1:6
    sym_err(k) = norm(dM_a(:,:,k) - dM_a(:,:,k).', 'fro');
end
fprintf('symmetry error of dM(:,:,k):\n');
disp(sym_err.');
