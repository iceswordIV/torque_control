function S = skew3(a)
%SKEW3 Skew-symmetric matrix.
S = [ 0,    -a(3),  a(2);
      a(3),  0,    -a(1);
     -a(2),  a(1),  0   ];
end
