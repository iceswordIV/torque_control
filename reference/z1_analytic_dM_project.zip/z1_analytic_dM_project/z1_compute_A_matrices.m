function [A, Gp] = z1_compute_A_matrices(q, p)
%Z1_COMPUTE_A_MATRICES Build A_lj and transformed spatial inertias.
%
% A_lj is the 6x6 adjoint matrix that transforms joint j's twist into
% link l's body chain coordinates, excluding the fixed home COM transform.
%
% For l > j:
%   A_lj = Ad_{(E_{j+1} ... E_l)^-1}
%
% For l == j:
%   A_lj = I
%
% For l < j:
%   A_lj = 0
%
% Gp(:,:,l) = Ad_{g_sl0^-1}' * G_l * Ad_{g_sl0^-1}
% so M_ij can be built as xi_i' A_li' Gp_l A_lj xi_j.

n = 6;
q = q(:);
[~, w_list, v_list] = z1_twists(p);

E = cell(n,1);
for i = 1:n
    E{i} = z1_twist_exp(w_list(:,i), v_list(:,i), q(i));
end

A = zeros(6,6,n,n);

for l = 1:n
    for j = 1:n
        if l < j
            A(:,:,l,j) = zeros(6,6);
        elseif l == j
            A(:,:,l,j) = eye(6);
        else
            g = eye(4);
            for r = j+1:l
                g = g * E{r};
            end
            A(:,:,l,j) = adjoint_inverse(g);
        end
    end
end

gsl0 = {p.gsl0_1, p.gsl0_2, p.gsl0_3, p.gsl0_4, p.gsl0_5, p.gsl0_6};
I_list = {p.I1, p.I2, p.I3, p.I4, p.I5, p.I6};

Gp = zeros(6,6,n);
for l = 1:n
    G = zeros(6,6);
    G(1:3,1:3) = p.m_vec(l) * eye(3);
    G(4:6,4:6) = I_list{l};

    A0 = adjoint_inverse(gsl0{l});
    Gp(:,:,l) = A0.' * G * A0;
end
end
