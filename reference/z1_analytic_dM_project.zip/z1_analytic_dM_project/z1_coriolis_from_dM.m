function C = z1_coriolis_from_dM(dM, dq)
%Z1_CORIOLIS_FROM_DM Build C(q,dq) from dM/dq.
%
% C_ij = 1/2 sum_k (dM_ij/dq_k + dM_ik/dq_j - dM_kj/dq_i) dq_k

n = 6;
dq = dq(:);
C = zeros(n,n);

for i = 1:n
    for j = 1:n
        cij = 0.0;
        for k = 1:n
            cij = cij + 0.5 * (dM(i,j,k) + dM(i,k,j) - dM(k,j,i)) * dq(k);
        end
        C(i,j) = cij;
    end
end
end
