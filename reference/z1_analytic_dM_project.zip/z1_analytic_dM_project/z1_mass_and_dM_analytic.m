function [M, dM] = z1_mass_and_dM_analytic(q, p)
%Z1_MASS_AND_DM_ANALYTIC Calculate M(q) and analytic dM/dq.
%
% This implements the book idea:
%
%   J_lj = A_lj * xi_j
%
%   d/dq_k J_lj = A_lk * [A_kj * xi_j, xi_k]
%
%   M_ij = sum_l J_li' * G_l' * J_lj
%
%   dM_ij/dq_k = sum_l dJ_li' * G_l' * J_lj + J_li' * G_l' * dJ_lj
%
% Here xi = [v; w].  The Lie bracket is implemented in lie_bracket_vw.m.

n = 6;
q = q(:);

[xi, ~, ~] = z1_twists(p);
[A, Gp] = z1_compute_A_matrices(q, p);

M = zeros(n,n);
dM = zeros(n,n,n);

% Precompute Jacobian columns J{l,j} = A_lj xi_j.
J = cell(n,n);
for l = 1:n
    for j = 1:n
        if l >= j
            J{l,j} = A(:,:,l,j) * xi(:,j);
        else
            J{l,j} = zeros(6,1);
        end
    end
end

% Mass matrix.
for i = 1:n
    for j = 1:n
        mij = 0.0;
        for l = max(i,j):n
            mij = mij + J{l,i}.' * Gp(:,:,l) * J{l,j};
        end
        M(i,j) = mij;
    end
end
M = 0.5 * (M + M.');

% Analytic dM.
for k = 1:n
    for i = 1:n
        for j = 1:n
            val = 0.0;
            for l = max(i,j):n
                dJ_li = z1_dJ_column_analytic(l, i, k, A, xi);
                dJ_lj = z1_dJ_column_analytic(l, j, k, A, xi);

                val = val + dJ_li.' * Gp(:,:,l) * J{l,j} + ...
                            J{l,i}.' * Gp(:,:,l) * dJ_lj;
            end
            dM(i,j,k) = val;
        end
    end
end
end
