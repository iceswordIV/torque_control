function [M, C, N, dM] = z1_dynamics_analytic(q, dq, p)
%Z1_DYNAMICS_ANALYTIC Calculate M, analytic dM, C, and N.
%
% This is the main live dynamics function.
% It uses the POE / Lie bracket formula for dM/dq.

[M, dM] = z1_mass_and_dM_analytic(q, p);
C = z1_coriolis_from_dM(dM, dq);
N = z1_gravity_vector_analytic(q, p);
end
