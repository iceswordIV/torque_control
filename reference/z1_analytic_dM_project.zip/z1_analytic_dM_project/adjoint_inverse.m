function Ad_inv = adjoint_inverse(g)
%ADJOINT_INVERSE Inverse adjoint for twist convention [v;w].

R = g(1:3,1:3);
p = g(1:3,4);

Ad_inv = zeros(6,6);
Ad_inv(1:3,1:3) = R.';
Ad_inv(1:3,4:6) = -R.' * skew3(p);
Ad_inv(4:6,4:6) = R.';
end
