function val = get_opt(opts, name, default_val)
%GET_OPT Safe option getter.
if isstruct(opts) && isfield(opts, name)
    val = opts.(name);
else
    val = default_val;
end
end
