clear;
clc;
close all;

%% Z1 analytic dM project
% Controller sends torque.
% Robot simulation calculates M, analytic dM, C, N live.
% No M_func/C_func/N_func are required for this simulation.

p = z1_parameters_analytic();

sim_opts = struct();
sim_opts.damping = 0.03 * ones(6,1);
sim_opts.ode_rel_tol = 1e-7;
sim_opts.ode_abs_tol = 1e-9;

ctrl = struct();
ctrl.Kp = [70; 70; 55; 35; 15; 10];
ctrl.Kd = [12; 12; 10; 7; 4; 3];
ctrl.use_gravity_compensation = true;

% Desired joint target [rad]
ctrl.q_goal = [0.20; 0.25; -0.25; 0.15; 0.10; 0.04];
ctrl.t0 = 0.3;
ctrl.Tmove = 1.5;

Ts = 0.01;
Tend = 3.0;
Nstep = round(Tend / Ts);

arm = Z1ArmSimAnalytic(p, sim_opts);

log_t = zeros(Nstep + 1, 1);
log_q = zeros(Nstep + 1, 6);
log_dq = zeros(Nstep + 1, 6);
log_tau = zeros(Nstep + 1, 6);

s = arm.getLowState();
log_q(1,:) = s.q.';
log_dq(1,:) = s.dq.';

for k = 1:Nstep
    t = (k-1) * Ts;

    lowstate = arm.getLowState();

    tau_cmd = z1_control_logic(t, lowstate.q, lowstate.dq, ctrl, p);

    cmd = z1_make_lowcmd();
    cmd.tau = tau_cmd;

    arm.sendLowCmd(cmd);
    arm.step(Ts);

    lowstate = arm.getLowState();

    log_t(k+1) = t + Ts;
    log_q(k+1,:) = lowstate.q.';
    log_dq(k+1,:) = lowstate.dq.';
    log_tau(k+1,:) = tau_cmd.';
end

assignin('base', 'log_t', log_t);
assignin('base', 'log_q', log_q);
assignin('base', 'log_dq', log_dq);
assignin('base', 'log_tau', log_tau);

figure;
plot(log_t, log_q, 'LineWidth', 1.2);
grid on;
xlabel('Time [s]');
ylabel('q [rad]');
title('Z1 analytic dM simulation: joint position');
legend('q1','q2','q3','q4','q5','q6', 'Location', 'best');

figure;
plot(log_t, log_dq, 'LineWidth', 1.2);
grid on;
xlabel('Time [s]');
ylabel('dq [rad/s]');
title('Z1 analytic dM simulation: joint velocity');
legend('dq1','dq2','dq3','dq4','dq5','dq6', 'Location', 'best');

figure;
plot(log_t, log_tau, 'LineWidth', 1.2);
grid on;
xlabel('Time [s]');
ylabel('tau command [N m]');
title('Z1 analytic dM simulation: commanded torque');
legend('tau1','tau2','tau3','tau4','tau5','tau6', 'Location', 'best');

disp('Finished Z1 analytic dM simulation.');
disp('Logs are in base workspace: log_t, log_q, log_dq, log_tau');
