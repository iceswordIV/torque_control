function out = lie_bracket_vw(xi1, xi2)
%LIE_BRACKET_VW Lie bracket for twist convention xi = [v; w].
%
% If xi1 = [v1; w1] and xi2 = [v2; w2], then:
%   [xi1, xi2] = [ w1 x v2 + v1 x w2 ; w1 x w2 ]
%
% This is equivalent to (hat(xi1)*hat(xi2) - hat(xi2)*hat(xi1)) vee.

v1 = xi1(1:3);
w1 = xi1(4:6);

v2 = xi2(1:3);
w2 = xi2(4:6);

out = [cross(w1, v2) + cross(v1, w2);
       cross(w1, w2)];
end
