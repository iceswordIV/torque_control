classdef Z1ArmSimAnalytic < handle
    %Z1ARMSIMANALYTIC Unitree-like arm simulator using analytic dM.
    %
    % Controller interface:
    %   lowstate = arm.getLowState();
    %   cmd = z1_make_lowcmd();
    %   cmd.tau = tau_cmd;
    %   arm.sendLowCmd(cmd);
    %   arm.step(Ts);

    properties
        q
        dq
        tau_cmd
        tau_meas
        p
        opts
    end

    methods
        function obj = Z1ArmSimAnalytic(p, opts)
            obj.p = p;
            obj.opts = opts;
            obj.q = zeros(6,1);
            obj.dq = zeros(6,1);
            obj.tau_cmd = zeros(6,1);
            obj.tau_meas = zeros(6,1);
        end

        function sendLowCmd(obj, cmd)
            if isfield(cmd, 'tau')
                obj.tau_cmd = cmd.tau(:);
            else
                error('cmd must contain field tau.');
            end
        end

        function step(obj, Ts)
            x0 = [obj.q; obj.dq];

            reltol = get_opt(obj.opts, 'ode_rel_tol', 1e-7);
            abstol = get_opt(obj.opts, 'ode_abs_tol', 1e-9);
            ode_opts = odeset('RelTol', reltol, 'AbsTol', abstol);

            [~, xout] = ode45(@(t, x) z1_robot_ode_analytic(t, x, obj.tau_cmd, obj.p, obj.opts), ...
                              [0, Ts], x0, ode_opts);

            x = xout(end,:).';
            obj.q = x(1:6);
            obj.dq = x(7:12);
            obj.tau_meas = obj.tau_cmd;
        end

        function lowstate = getLowState(obj)
            lowstate = struct();
            lowstate.q = obj.q;
            lowstate.dq = obj.dq;
            lowstate.tau = obj.tau_meas;
        end
    end
end
