function [q_des, dq_des, ddq_des] = z1_desired_trajectory(t, q_goal, t0, Tmove)
%Z1_DESIRED_TRAJECTORY Smooth 5th-order rest-to-rest trajectory.

q_goal = q_goal(:);

s = (t - t0) / Tmove;

if s <= 0
    b = 0;
    bd = 0;
    bdd = 0;
elseif s >= 1
    b = 1;
    bd = 0;
    bdd = 0;
else
    b = 10*s^3 - 15*s^4 + 6*s^5;
    bd = (30*s^2 - 60*s^3 + 30*s^4) / Tmove;
    bdd = (60*s - 180*s^2 + 120*s^3) / Tmove^2;
end

q_des = q_goal * b;
dq_des = q_goal * bd;
ddq_des = q_goal * bdd;
end
