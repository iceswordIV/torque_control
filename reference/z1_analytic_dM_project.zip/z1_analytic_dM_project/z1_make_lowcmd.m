function cmd = z1_make_lowcmd()
%Z1_MAKE_LOWCMD Small Unitree-like torque command struct.
cmd = struct();
cmd.tau = zeros(6,1);
end
