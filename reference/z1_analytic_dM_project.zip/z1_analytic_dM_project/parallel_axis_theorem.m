function I_shifted = parallel_axis_theorem(I_body, m_body, displacement)
%PARALLEL_AXIS_THEOREM Translate inertia to a new reference point.
d = displacement(:);
d_squared = dot(d, d);
d_outer = d * d.';
I_shifted = I_body + m_body * (d_squared * eye(3) - d_outer);
end
