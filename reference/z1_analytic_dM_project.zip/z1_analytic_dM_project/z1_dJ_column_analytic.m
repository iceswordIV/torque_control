function dJ = z1_dJ_column_analytic(l, j, k, A, xi)
%Z1_DJ_COLUMN_ANALYTIC Analytic derivative of one Jacobian column.
%
% J_lj = A_lj * xi_j
%
% dJ_lj/dq_k = A_lk * [A_kj * xi_j, xi_k]
%
% This derivative is zero if joint k is not between j and l.

if ~(l >= k && k >= j)
    dJ = zeros(6,1);
    return;
end

A_lk = A(:,:,l,k);
A_kj_xi_j = A(:,:,k,j) * xi(:,j);
xi_k = xi(:,k);

dJ = A_lk * lie_bracket_vw(A_kj_xi_j, xi_k);
end
