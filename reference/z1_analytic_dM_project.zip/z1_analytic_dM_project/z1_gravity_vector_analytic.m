function N = z1_gravity_vector_analytic(q, p)
%Z1_GRAVITY_VECTOR_ANALYTIC Analytic gravity vector from COM Jacobians.
%
% Potential energy V = sum_l m_l g z_l.
% N_j = dV/dq_j = sum_l m_l g dz_l/dq_j.
%
% The COM derivative is computed from the space twist of joint j:
%   dp/dq_j = v_j + w_j x p_com.

n = 6;
q = q(:);
[xi, w_list, v_list] = z1_twists(p);

gsl0 = {p.gsl0_1, p.gsl0_2, p.gsl0_3, p.gsl0_4, p.gsl0_5, p.gsl0_6};

E = cell(n,1);
for i = 1:n
    E{i} = z1_twist_exp(w_list(:,i), v_list(:,i), q(i));
end

% COM positions in base frame.
p_com = zeros(3,n);
for l = 1:n
    g = eye(4);
    for r = 1:l
        g = g * E{r};
    end
    g_com = g * gsl0{l};
    p_com(:,l) = g_com(1:3,4);
end

% Space Jacobian columns for each joint.
J_space = zeros(6,n);
T_prev = eye(4);
for j = 1:n
    J_space(:,j) = adjoint(T_prev) * xi(:,j);
    T_prev = T_prev * E{j};
end

N = zeros(n,1);
for j = 1:n
    for l = j:n
        vj = J_space(1:3,j);
        wj = J_space(4:6,j);
        dp = vj + cross(wj, p_com(:,l));
        N(j) = N(j) + p.m_vec(l) * p.g_const * dp(3);
    end
end
end
