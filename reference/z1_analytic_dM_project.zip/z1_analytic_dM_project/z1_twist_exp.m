function g = z1_twist_exp(w, v, theta)
%Z1_TWIST_EXP Homogeneous transform e^[xi_hat theta], xi=[v;w].

R = z1_rodrigues(w, theta);
p = (eye(3) - R) * (skew3(w) * v) + w * (w.' * v) * theta;

g = eye(4);
g(1:3,1:3) = R;
g(1:3,4) = p;
end
