Z1 analytic dM project
=======================

This MATLAB project simulates a Unitree Z1-style 6-DOF arm with torque input.

Main idea
---------
It calculates M(q), dM/dq, C(q,dq), and N(q) live during simulation.
The Coriolis matrix is NOT built using symbolic diff and NOT built using finite difference.
Instead, dM/dq is calculated analytically using the product-of-exponentials / Lie bracket formula:

    d/dq_k (A_lj xi_j) = A_lk [A_kj xi_j, xi_k]

Then:

    dM_ij/dq_k = sum_l dJ_li/dq_k' * G_l * J_lj + J_li' * G_l * dJ_lj/dq_k

and:

    C_ij = 1/2 * sum_k (dM_ij/dq_k + dM_ik/dq_j - dM_kj/dq_i) * dq_k

Run
---
Open MATLAB in this folder and run:

    main_z1_analytic_dM_project

Optional comparison
-------------------
If M_func.m, C_func.m, and N_func.m are in this folder, run:

    compare_analytic_dM_with_generated

This compares:

    analytic M vs generated M_func
    analytic C*dq vs generated C_func*dq
    analytic N vs generated N_func
    analytic ddq vs generated ddq

Notes
-----
- The simulation does not need M_func/C_func/N_func.
- The optional comparison script uses generated files only as a reference.
- If signs do not match your own convention, check the Lie bracket order in lie_bracket_vw.m and the A_ij convention in z1_compute_A_matrices.m.
