function dx = z1_robot_ode_analytic(~, x, tau_cmd, p, opts)
%Z1_ROBOT_ODE_ANALYTIC Forward dynamics using analytic dM Coriolis.

q = x(1:6);
dq = x(7:12);

[M, C, N] = z1_dynamics_analytic(q, dq, p);

Bdiag = get_opt(opts, 'damping', zeros(6,1));
B = diag(Bdiag(:));

ddq = M \ (tau_cmd(:) - C*dq - N - B*dq);

dx = [dq; ddq];
end
