function R = z1_rodrigues(w, theta)
%Z1_RODRIGUES Rodrigues formula for e^[w_hat theta].

nw = norm(w);
if nw < 1e-12
    R = eye(3);
    return;
end

wh = skew3(w);
if abs(nw - 1.0) < 1e-12
    R = eye(3) + wh*sin(theta) + wh*wh*(1 - cos(theta));
else
    R = eye(3) + wh/nw*sin(nw*theta) + wh*wh/(nw^2)*(1 - cos(nw*theta));
end
end
