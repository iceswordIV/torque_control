function g = make_g(R, p)
%MAKE_G Build homogeneous transform.
g = eye(4);
g(1:3,1:3) = R;
g(1:3,4) = p(:);
end
