function Ad = adjoint(g)
%ADJOINT Adjoint of homogeneous transform for twist convention [v;w].

R = g(1:3,1:3);
p = g(1:3,4);

Ad = zeros(6,6);
Ad(1:3,1:3) = R;
Ad(1:3,4:6) = skew3(p) * R;
Ad(4:6,4:6) = R;
end
