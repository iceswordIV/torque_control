function [twists, w_list, v_list] = z1_twists(p)
%Z1_TWISTS Build revolute twists [v; w] for Z1 joints.

w_list = [p.w1, p.w2, p.w3, p.w4, p.w5, p.w6];
q_home = [p.q1, p.q2, p.q3, p.q4, p.q5, p.q6];

v_list = zeros(3,6);
twists = zeros(6,6);

for i = 1:6
    w = w_list(:,i);
    q0 = q_home(:,i);
    v = -cross(w, q0);

    v_list(:,i) = v;
    twists(:,i) = [v; w];
end
end
